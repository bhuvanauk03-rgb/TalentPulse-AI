// ============================================================
// TALENTPULSE AI - FRONTEND APPLICATION
// ============================================================

const API_URL =
  "https://xhrw4xpw61.execute-api.ap-south-1.amazonaws.com";

const REQUIRED_SKILLS = [
  "AWS",
  "Cloud Computing",
  "Python",
  "Java",
  "SQL",
  "Docker",
  "Git",
  "Machine Learning"
];

let candidates = [];

// ============================================================
// INITIALIZE
// ============================================================

document.addEventListener("DOMContentLoaded", () => {
  setupNavigation();
  setupUpload();
  setupButtons();

  loadCandidates();

  updateAudit("TalentPulse dashboard initialized");
});

// ============================================================
// NAVIGATION
// ============================================================

function setupNavigation() {

  const navItems =
    document.querySelectorAll(".nav-item");

  navItems.forEach(item => {

    item.addEventListener("click", () => {

      navItems.forEach(nav =>
        nav.classList.remove("active")
      );

      item.classList.add("active");
    });

  });
}

// ============================================================
// BUTTONS
// ============================================================

function setupButtons() {

  const refreshBtn =
    document.getElementById("refreshBtn");

  const refreshCandidates =
    document.getElementById("refreshCandidates");

  if (refreshBtn) {

    refreshBtn.addEventListener("click", () => {
      loadCandidates();
    });

  }

  if (refreshCandidates) {

    refreshCandidates.addEventListener("click", () => {
      loadCandidates();
    });

  }

  const signInBtn =
    document.getElementById("signInBtn");

  if (signInBtn) {

    signInBtn.addEventListener("click", () => {

      const domain =
        "https://ap-south-1jxvptg5m.auth.ap-south-1.amazoncognito.com";

      const clientId =
        "16h7nk3soiq43cv8fat01t473a";

      const redirectUri =
        window.location.origin +
        window.location.pathname;

      const loginUrl =
        domain +
        "/oauth2/authorize" +
        "?client_id=" +
        encodeURIComponent(clientId) +
        "&response_type=code" +
        "&scope=openid+email" +
        "&redirect_uri=" +
        encodeURIComponent(redirectUri);

      window.location.href = loginUrl;

    });

  }
}

// ============================================================
// RESUME UPLOAD
// ============================================================

function setupUpload() {
  const fileInput = document.getElementById("resumeFile");
  if (!fileInput) return;

  fileInput.multiple = true;
  fileInput.addEventListener("change", async event => {
    const selected = Array.from(event.target.files || []);
    if (!selected.length) return;
    // Reset so the same files can be selected again later.
    fileInput.value = "";

    const valid = selected.filter(file =>
      file.type === "application/pdf" || file.name.toLowerCase().endsWith(".pdf")
    );
    const rejected = selected.length - valid.length;
    if (!valid.length) {
      setStatus("Please select one or more PDF resumes.", true);
      return;
    }
    if (rejected) setStatus(`${rejected} non-PDF file(s) skipped. Processing ${valid.length} PDF(s).`, true);
    await processResumeBatch(valid);
  });
}

async function processResumeBatch(files) {
  const panel = document.getElementById("bulkProgressPanel");
  const label = document.getElementById("bulkProgressLabel");
  const count = document.getElementById("bulkProgressCount");
  const bar = document.getElementById("bulkProgressBar");
  const successEl = document.getElementById("bulkSuccessCount");
  const failedEl = document.getElementById("bulkFailedCount");
  const list = document.getElementById("bulkFileResults");
  if (panel) panel.style.display = "block";
  if (list) list.innerHTML = "";
  let successful = 0;
  let failed = 0;

  const updateProgress = (done, currentName) => {
    const percent = Math.round((done / files.length) * 100);
    if (label) label.textContent = done === files.length ? "Batch complete" : `Processing: ${currentName}`;
    if (count) count.textContent = `${done} / ${files.length} (${percent}%)`;
    if (bar) bar.style.width = `${percent}%`;
    if (successEl) successEl.textContent = successful;
    if (failedEl) failedEl.textContent = failed;
  };

  setStatus(`Starting bulk processing of ${files.length} PDF resume(s)…`);
  updateAudit(`Bulk resume batch started: ${files.length} file(s)`);
  for (let i = 0; i < files.length; i++) {
    const file = files[i];
    let ok = false;
    try {
      setStatus(`Processing resume ${i + 1} of ${files.length}: ${file.name}`);
      ok = await processResume(file);
    } catch (error) {
      console.error(`Failed to process ${file.name}`, error);
    }
    if (ok) successful++; else failed++;
    if (list) {
      const item = document.createElement("li");
      item.style.marginBottom = "6px";
      item.textContent = `${ok ? "✓" : "✕"} ${file.name} — ${ok ? "Processed" : "Failed; see status/audit log"}`;
      item.style.color = ok ? "#34d399" : "#fb7185";
      list.appendChild(item);
    }
    updateProgress(i + 1, file.name);
  }
  setStatus(`Bulk processing finished: ${successful} successful, ${failed} failed${failed ? ". Check failed PDFs and try again." : "."}`, failed > 0);
  updateAudit(`Bulk batch finished: ${successful} successful, ${failed} failed`);
  await loadCandidates();
}

// ============================================================
// PROCESS RESUME
// ============================================================

async function processResume(file) {

  try {

    setStatus(
      "Reading resume PDF..."
    );

    updateAudit(
      `Resume selected: ${file.name}`
    );

    // Extract PDF text
    const text =
      await extractPdfText(file);

    if (
      !text ||
      text.trim().length < 20
    ) {

      throw new Error(
        "No readable text found in PDF."
      );

    }

    setStatus(
      "Resume text extracted. Sending candidate to AI matching engine..."
    );

    updateAudit(
      "Resume text extracted successfully"
    );

    // Create candidate
    const candidate =
      buildCandidateFromResume(
        text,
        file.name
      );

    // Send to AWS
    const result =
      await sendCandidate(candidate);

    // Display the latest result in the original summary card
    displayResult(result);

    // Keep every processed resume visible in the bulk results area
    displayBulkResult(result, file.name);

    setStatus(
      "Resume processed successfully."
    );

    updateAudit(
      `Candidate processed: ${
        result.candidateName ||
        "Candidate"
      }`
    );

    // Refresh candidate table
    await loadCandidates();
    return true;

  } catch (error) {

    console.error(
      "Resume processing error:",
      error
    );

    setStatus(
      "Failed to process resume: " +
      error.message,
      true
    );

    updateAudit(
      "Resume processing failed"
    );
    return false;

  }
}

// ============================================================
// PDF.JS LOADER
// ============================================================

function loadPdfJs() {

  return new Promise(
    (resolve, reject) => {

      // Already loaded
      if (window.pdfjsLib) {

        window.pdfjsLib.GlobalWorkerOptions.workerSrc =
          "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js";

        resolve();

        return;
      }

      const script =
        document.createElement("script");

      script.src =
        "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js";

      script.onload = () => {

        if (window.pdfjsLib) {

          window.pdfjsLib.GlobalWorkerOptions.workerSrc =
            "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js";

          resolve();

        } else {

          reject(
            new Error(
              "PDF.js failed to initialize."
            )
          );

        }

      };

      script.onerror = () => {

        reject(
          new Error(
            "Unable to load PDF.js. Check internet connection."
          )
        );

      };

      document.head.appendChild(script);

    }
  );
}

// ============================================================
// EXTRACT TEXT FROM PDF
// ============================================================

async function extractPdfText(file) {

  // Load PDF.js
  await loadPdfJs();

  // Read file
  const arrayBuffer =
    await file.arrayBuffer();

  // Load PDF
  const pdf =
    await window.pdfjsLib.getDocument({
      data: arrayBuffer
    }).promise;

  let fullText = "";

  // Read every page
  for (
    let pageNumber = 1;
    pageNumber <= pdf.numPages;
    pageNumber++
  ) {

    const page =
      await pdf.getPage(pageNumber);

    const textContent =
      await page.getTextContent();

    const pageText =
      textContent.items
        .map(item => item.str)
        .join(" ");

    fullText +=
      pageText + "\n";

  }

  return fullText.trim();
}

// ============================================================
// BUILD CANDIDATE
// ============================================================

function buildCandidateFromResume(
  text,
  fileName
) {

  const normalizedText =
    text.toLowerCase();

  // Detect required skills
  const skills =
    REQUIRED_SKILLS.filter(
      skill =>
        normalizedText.includes(
          skill.toLowerCase()
        )
    );

  // Extract name
  let candidateName =
    extractName(text);

  // If name not detected,
  // use filename
  if (!candidateName) {

    candidateName =
      fileName
        .replace(/\.pdf$/i, "")
        .replace(/[_-]+/g, " ")
        .trim();

  }

  // Extract email
  const emailMatch =
    text.match(
      /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i
    );

  // Extract experience
  const experienceMatch =
    text.match(
      /(\d+(?:\.\d+)?)\s*\+?\s*(?:years|year|yrs|yr)/i
    );

  // Extract education
  const education =
    extractEducation(text);

  return {

    candidateId:
      "CAND-" +
      Date.now(),

    candidateName:
      candidateName,

    email:
      emailMatch
        ? emailMatch[0]
        : "candidate@talentpulse.ai",

    resumeText:
      text,

    skills:
      skills.join(", "),

    experienceYears:
      experienceMatch
        ? Number(
            experienceMatch[1]
          )
        : 0,

    education:
      education,

    status:
      "PROCESSING",

    resumeFileName:
      fileName

  };
}

// ============================================================
// EXTRACT NAME
// ============================================================

function extractName(text) {

  const lines =
    text
      .split(/\r?\n/)
      .map(line =>
        line.trim()
      )
      .filter(Boolean);

  for (
    const line of lines.slice(0, 10)
  ) {

    if (

      line.length >= 3 &&

      line.length <= 60 &&

      !line.includes("@") &&

      !/\d{3,}/.test(line) &&

      !/resume|curriculum|profile|email|phone|mobile/i.test(
        line
      )

    ) {

      return line;

    }

  }

  return "";
}

// ============================================================
// EXTRACT EDUCATION
// ============================================================

function extractEducation(text) {

  const educationPatterns = [

    "M.Tech",
    "MTech",
    "M.E",
    "ME",
    "MCA",
    "MBA",
    "B.Tech",
    "BTech",
    "B.E",
    "BE",
    "BCA",
    "B.Sc",
    "BSc",
    "Computer Science",
    "Software Engineering"

  ];

  for (
    const education
    of educationPatterns
  ) {

    if (
      text
        .toLowerCase()
        .includes(
          education.toLowerCase()
        )
    ) {

      return education;

    }

  }

  return "Not specified";
}

// ============================================================
// SEND CANDIDATE TO API GATEWAY
// ============================================================

async function sendCandidate(
  candidate
) {

  const response =
    await fetch(
      `${API_URL}/candidates`,
      {

        method: "POST",

        headers: {
          "Content-Type":
            "application/json"
        },

        body:
          JSON.stringify(candidate)

      }
    );

  if (!response.ok) {

    throw new Error(
      `API returned ${response.status}`
    );

  }

  const data =
    await response.json();

  return unwrapApiResponse(
    data
  );
}

// ============================================================
// LOAD CANDIDATES
// ============================================================

async function loadCandidates() {

  try {

    const response =
      await fetch(
        `${API_URL}/candidates`,
        {
          method: "GET"
        }
      );

    if (!response.ok) {

      throw new Error(
        `API returned ${response.status}`
      );

    }

    const data =
      await response.json();

    candidates =
      unwrapApiResponse(
        data
      );

    if (
      !Array.isArray(candidates)
    ) {

      candidates = [];

    }

    // Sort highest score first
    candidates.sort(
      (a, b) =>
        Number(
          b.matchScore || 0
        ) -
        Number(
          a.matchScore || 0
        )
    );

    // Add ranking
    candidates =
      candidates.map(
        (candidate, index) => ({
          ...candidate,
          ranking: index + 1
        })
      );

    renderCandidates();

    updateDashboard();

    renderSkillMatrix();

    renderPipeline();

  } catch (error) {

    console.error(
      "Candidate loading error:",
      error
    );

    const table =
      document.getElementById(
        "candidateTable"
      );

    if (table) {

      table.innerHTML = `
        <tr>
          <td colspan="6" class="empty">
            Unable to connect to TalentPulse API.
          </td>
        </tr>
      `;

    }

    updateAudit(
      "Candidate API connection failed"
    );

  }
}

// ============================================================
// UNWRAP API RESPONSE
// ============================================================

function unwrapApiResponse(
  data
) {

  // Direct array
  if (
    Array.isArray(data)
  ) {

    return data;

  }

  // { candidates: [] }
  if (
    data &&
    Array.isArray(
      data.candidates
    )
  ) {

    return data.candidates;

  }

  // API Gateway body
  if (
    data &&
    data.body
  ) {

    try {

      const parsed =
        typeof data.body === "string"
          ? JSON.parse(
              data.body
            )
          : data.body;

      if (
        Array.isArray(parsed)
      ) {

        return parsed;

      }

      if (
        parsed &&
        Array.isArray(
          parsed.candidates
        )
      ) {

        return parsed.candidates;

      }

      return parsed;

    } catch {

      return data;

    }

  }

  return data;
}

// ============================================================
// DISPLAY NEW RESULT
// ============================================================

function displayResult(
  candidate
) {

  const card =
    document.getElementById(
      "resultCard"
    );

  if (!card) return;

  card.classList.remove(
    "hidden"
  );

  const name =
    candidate.candidateName ||
    "Unknown Candidate";

  const score =
    Number(
      candidate.matchScore || 0
    );

  const classification =
    candidate.classification ||
    getClassification(score);

  const status =
    candidate.status ||
    "AI_PROCESSED";

  document.getElementById(
    "resultName"
  ).textContent =
    name;

  document.getElementById(
    "resultScore"
  ).textContent =
    `${score}%`;

  document.getElementById(
    "resultClass"
  ).textContent =
    classification;

  document.getElementById(
    "resultStatus"
  ).textContent =
    status;

  renderSkillTags(
    "matchedSkills",
    candidate.matchedSkills
  );

  renderSkillTags(
    "missingSkills",
    candidate.missingSkills
  );
}


// ============================================================
// DISPLAY EVERY RESULT IN THE BULK RESULTS AREA
// ============================================================
function displayBulkResult(candidate, fileName) {
  const container = document.getElementById("bulkResults");
  if (!container) return;

  const result = candidate && typeof candidate === "object" ? candidate : {};
  const name = result.candidateName || result.name || fileName.replace(/\.pdf$/i, "").replace(/[_-]+/g, " ");
  const rawScore = result.matchScore ?? result.score;
  const score = Number.isFinite(Number(rawScore)) ? Number(rawScore) : null;
  const classification = result.classification || result.decision || (score === null ? "Pending review" : getClassification(score));
  const status = result.status || "Processed";
  const matched = normalizeSkillList(result.matchedSkills || result.skills || []);
  const missing = normalizeSkillList(result.missingSkills || []);

  const card = document.createElement("article");
  card.className = "bulk-result-card";

  const details = document.createElement("div");
  const heading = document.createElement("h3");
  heading.textContent = name;
  details.appendChild(heading);

  const meta = document.createElement("div");
  meta.className = "candidate-meta";
  meta.textContent = fileName + " · " + status;
  details.appendChild(meta);

  const scoreEl = document.createElement("div");
  scoreEl.className = "match-score";
  scoreEl.textContent = score === null ? "Score unavailable" : `${score}% match`;
  details.appendChild(scoreEl);

  const decision = document.createElement("div");
  decision.className = "candidate-meta";
  decision.textContent = `AI Decision: ${classification}`;
  details.appendChild(decision);

  const skills = document.createElement("div");
  skills.className = "skills-result";
  const matchedTitle = document.createElement("strong");
  matchedTitle.textContent = "Matched skills";
  skills.appendChild(matchedTitle);
  const matchedList = document.createElement("div");
  matchedList.className = "skill-list";
  if (matched.length) {
    matched.forEach(skill => {
      const tag = document.createElement("span");
      tag.className = "skill-tag matched";
      tag.textContent = skill;
      matchedList.appendChild(tag);
    });
  } else {
    matchedList.textContent = "No matched skills returned by API.";
  }
  skills.appendChild(matchedList);

  const missingTitle = document.createElement("strong");
  missingTitle.textContent = "Missing skills";
  missingTitle.style.display = "block";
  missingTitle.style.marginTop = "10px";
  skills.appendChild(missingTitle);
  const missingList = document.createElement("div");
  missingList.className = "skill-list";
  if (missing.length) {
    missing.forEach(skill => {
      const tag = document.createElement("span");
      tag.className = "skill-tag missing";
      tag.textContent = skill;
      missingList.appendChild(tag);
    });
  } else {
    missingList.textContent = "No missing skills returned.";
  }
  skills.appendChild(missingList);
  details.appendChild(skills);

  const scoreBadge = document.createElement("div");
  scoreBadge.className = "candidate-score-badge";
  scoreBadge.textContent = score === null ? "—" : `${score}%`;

  card.appendChild(details);
  card.appendChild(scoreBadge);
  container.appendChild(card);
}

function normalizeSkillList(value) {
  if (Array.isArray(value)) return value.map(v => String(v).trim()).filter(Boolean);
  return String(value || "").split(",").map(v => v.trim()).filter(Boolean);
}

// ============================================================
// RENDER SKILL TAGS
// ============================================================

function renderSkillTags(
  elementId,
  skills
) {

  const element =
    document.getElementById(
      elementId
    );

  if (!element) return;

  let list = [];

  if (
    Array.isArray(skills)
  ) {

    list = skills;

  } else {

    list =
      String(
        skills || ""
      )
        .split(",")
        .map(
          skill =>
            skill.trim()
        )
        .filter(Boolean);

  }

  if (!list.length) {

    element.innerHTML =
      "<span>None</span>";

    return;

  }

  element.innerHTML =
    list
      .map(
        skill =>
          `<span>${escapeHtml(
            skill
          )}</span>`
      )
      .join("");

}

// ============================================================
// CANDIDATE TABLE
// ============================================================

function renderCandidates() {

  const table =
    document.getElementById(
      "candidateTable"
    );

  if (!table) return;

  if (
    !candidates.length
  ) {

    table.innerHTML = `
      <tr>
        <td colspan="6" class="empty">
          No candidates found.
        </td>
      </tr>
    `;

    return;

  }

  table.innerHTML =
    candidates
      .map(
        (candidate, index) => {

          const score =
            Number(
              candidate.matchScore ||
              0
            );

          const scoreClass =
            score >= 80
              ? "score-high"
              : score >= 60
              ? "score-mid"
              : "score-low";

          const skills =
            candidate.skills ||
            candidate.matchedSkills ||
            "";

          const classification =
            candidate.classification ||
            getClassification(
              score
            );

          const status =
            candidate.status ||
            "PROCESSED";

          return `

            <tr>

              <td>
                <b>#${index + 1}</b>
              </td>

              <td>
                <strong>
                  ${escapeHtml(
                    candidate.candidateName ||
                    "Unknown"
                  )}
                </strong>
              </td>

              <td>
                ${escapeHtml(
                  Array.isArray(
                    skills
                  )
                    ? skills.join(
                        ", "
                      )
                    : String(
                        skills
                      )
                )}
              </td>

              <td>

                <span
                  class="score-badge ${scoreClass}"
                >
                  ${score}%
                </span>

              </td>

              <td class="classification">

                ${escapeHtml(
                  classification
                )}

              </td>

              <td>

                ${escapeHtml(
                  status
                )}

              </td>

            </tr>

          `;

        }
      )
      .join("");
}

// ============================================================
// DASHBOARD STATISTICS
// ============================================================

function updateDashboard() {

  const total =
    candidates.length;

  const processed =
    candidates.filter(
      candidate =>
        String(
          candidate.status || ""
        )
          .toUpperCase()
          .includes(
            "PROCESSED"
          )
    ).length;

  const strong =
    candidates.filter(
      candidate =>
        Number(
          candidate.matchScore ||
          0
        ) >= 80
    ).length;

  const top =
    candidates.length
      ? Math.max(
          ...candidates.map(
            candidate =>
              Number(
                candidate.matchScore ||
                0
              )
          )
        )
      : 0;

  setText(
    "statCandidates",
    total
  );

  setText(
    "statProcessed",
    processed
  );

  setText(
    "statStrong",
    strong
  );

  setText(
    "statTop",
    `${top}%`
  );
}

// ============================================================
// SKILL MATRIX
// ============================================================

function renderSkillMatrix() {

  const container =
    document.getElementById(
      "skillMatrix"
    );

  if (!container) return;

  container.innerHTML =
    REQUIRED_SKILLS
      .map(skill => {

        let count = 0;

        candidates.forEach(
          candidate => {

            const rawSkills =
              candidate.skills ||
              "";

            const skills =
              Array.isArray(
                rawSkills
              )
                ? rawSkills
                : String(
                    rawSkills
                  )
                    .split(",")
                    .map(
                      s =>
                        s.trim()
                    );

            if (
              skills.some(
                currentSkill =>
                  currentSkill
                    .toLowerCase() ===
                  skill.toLowerCase()
              )
            ) {

              count++;

            }

          }
        );

        const percentage =
          candidates.length
            ? Math.round(
                (
                  count /
                  candidates.length
                ) *
                  100
              )
            : 0;

        return `

          <div class="skill-row">

            <div class="skill-name">
              ${skill}
            </div>

            <div class="skill-bar">

              <div
                class="skill-fill"
                style="width:${percentage}%"
              ></div>

            </div>

            <div class="skill-percent">
              ${percentage}%
            </div>

          </div>

        `;

      })
      .join("");
}

// ============================================================
// HIRING PIPELINE
// ============================================================

function renderPipeline() {

  const container =
    document.getElementById(
      "pipelineStats"
    );

  if (!container) return;

  const excellent =
    candidates.filter(
      candidate =>
        Number(
          candidate.matchScore ||
          0
        ) >= 90
    ).length;

  const strong =
    candidates.filter(
      candidate => {

        const score =
          Number(
            candidate.matchScore ||
            0
          );

        return (
          score >= 80 &&
          score < 90
        );

      }
    ).length;

  const good =
    candidates.filter(
      candidate => {

        const score =
          Number(
            candidate.matchScore ||
            0
          );

        return (
          score >= 70 &&
          score < 80
        );

      }
    ).length;

  const below =
    candidates.filter(
      candidate =>
        Number(
          candidate.matchScore ||
          0
        ) < 70
    ).length;

  container.innerHTML = `

    <div class="pipeline-card">
      <span>Excellent</span>
      <strong>${excellent}</strong>
    </div>

    <div class="pipeline-card">
      <span>Strong</span>
      <strong>${strong}</strong>
    </div>

    <div class="pipeline-card">
      <span>Good</span>
      <strong>${good}</strong>
    </div>

    <div class="pipeline-card">
      <span>Below 70%</span>
      <strong>${below}</strong>
    </div>

  `;
}

// ============================================================
// CLASSIFICATION
// ============================================================

function getClassification(
  score
) {

  if (score >= 90) {

    return "Excellent Match";

  }

  if (score >= 80) {

    return "Strong Match";

  }

  if (score >= 70) {

    return "Good Match";

  }

  if (score >= 60) {

    return "Moderate Match";

  }

  return "Low Match";
}

// ============================================================
// STATUS MESSAGE
// ============================================================

function setStatus(
  message,
  error = false
) {

  const element =
    document.getElementById(
      "uploadStatus"
    );

  if (!element) return;

  element.textContent =
    message;

  element.style.borderColor =
    error
      ? "rgba(239,68,68,.35)"
      : "rgba(0,229,255,.12)";

  element.style.color =
    error
      ? "#fb7185"
      : "#aab4d2";
}

// ============================================================
// AUDIT LOG
// ============================================================

function updateAudit(
  message
) {

  const log =
    document.getElementById(
      "auditLog"
    );

  if (!log) return;

  const item =
    document.createElement(
      "div"
    );

  item.textContent =
    `${new Date().toLocaleTimeString()} — ${message}`;

  log.prepend(item);

  while (
    log.children.length > 6
  ) {

    log.removeChild(
      log.lastChild
    );

  }
}

// ============================================================
// TEXT HELPER
// ============================================================

function setText(
  id,
  value
) {

  const element =
    document.getElementById(
      id
    );

  if (element) {

    element.textContent =
      value;

  }
}

// ============================================================
// HTML SECURITY HELPER
// ============================================================

function escapeHtml(
  value
) {

  return String(value)

    .replace(
      /&/g,
      "&amp;"
    )

    .replace(
      /</g,
      "&lt;"
    )

    .replace(
      />/g,
      "&gt;"
    )

    .replace(
      /"/g,
      "&quot;"
    )

    .replace(
      /'/g,
      "&#039;"
    );
}